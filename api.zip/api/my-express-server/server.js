const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

app.get('/echo', (req, res) => {
  const text = req.query.text;
  res.json({ text });
});

app.get('/length', (req, res) => {
  const text = req.query.text || '';
  res.json({ length: text.length });
});

app.get('/reverse', (req, res) => {
  const text = req.query.text || '';
  const reversed = text.split('').reverse().join('');
  res.json({ reversed });
});

app.get('/case', (req, res) => {
  const { text = '', type = '' } = req.query;
  let result = '';
  if (type === 'upper') {
    result = text.toUpperCase();
  } else if (type === 'lower') {
    result = text.toLowerCase();
  }
  res.json({ result });
});

app.get('/count-chars', (req, res) => {
  const { text = '', char } = req.query;
  if (!char || char.length !== 1) {
    return res.status(400).json({ error: 'Параметр char обязателен и должен быть один символ' });
  }
  const count = Array.from(text).filter(c => c === char).length;
  res.json({ count });
});

app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});